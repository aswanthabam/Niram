### Python Niram

This is a simple module to get coloured text in linux, max , and also in android termux (not supported in windows CMD)

usage:
```python
from Niram import Colours
Colours().colour(colour_code,your_text,second=your_next_colour_code)
```
This will return the formated text
here colour_code is a number of the colour get it by executing
```console
python3 -m Niram -c
```
This will list out all colours and responsible number
Second argument is your text and third argument "second" is the background colour or any other colour you need 